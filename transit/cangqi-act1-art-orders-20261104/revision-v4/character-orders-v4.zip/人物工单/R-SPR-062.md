# R-SPR-062　柳浅 · 沉静

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

地上摊了一堆破书，旁人已经开口，她还要亲眼看一看才肯判断。眉弧舒平，长眼的焦点落在书页上，嘴唇松松合着，留出她认真看东西时的安静。

- **眉**　缓眉舒平
- **眼与视线**　长眼专注
- **嘴**　唇角松
- **演出用途**　先看散落的书，再判断天离的解释
- **表演依据**　41:L32
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_liuqian_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；两手轻叠于袖前，露出能拿家书的指尖；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

40、41

### 原文锚点

41:L32；41:L32、41:L37、42:L30、43:L11、43:L50；40:L34、40:L49、41:L32、43:L11

### 镜头、时段及状态

青裙暗纹靴；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_liuqian（少年·太学同窗）（D-CH-018）、ch_liuqian/c01（D-COS-025）

### 画面内必须可见

补：椭圆脸、平缓柳眉、长而沉静的眼；补：黑发低束，素布带收发；青裙，袖内可收信，暗纹靴；补：素发带，腰带齐平

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

两手轻叠于袖前，露出能拿家书的指尖

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-064 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. adolescent girl, soft oval face, gently arched slim brows, long attentive eyes, black hair tied low with a plain band, slender frame blue-green skirt, gray-green broad-sleeved top with room for a folded letter, boots with subtle tone-on-tone embroidery, plain hair ribbon front-facing natural standing pose at eye level, relaxed shoulders, hands gently folded in front of sleeves, fingertips visible She withholds judgment to study the worn books herself. Smooth brows, long eyes with a clear point of focus, gently resting closed lips.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_liuqian_p01_c01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-018、D-COS-025、R-SPR-064

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
