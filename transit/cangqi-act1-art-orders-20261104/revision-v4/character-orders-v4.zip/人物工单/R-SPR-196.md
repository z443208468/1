# R-SPR-196　周司业 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

王府送来的孩子到了跟前，周司业也得先问清姓名来历。这是管学务的人惯常的认真。眉梢略沉，视线正正落在对方脸上，唇线在修齐的须上方收稳，等他答话。

- **眉**　眉梢略低
- **眼与视线**　正面看人，目光稳定
- **嘴**　唇线收稳，颏须保留
- **演出用途**　听过来历，先按太学规矩问人
- **表演依据**　32:L38、32:L39、33:L27
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_zhou_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

38

### 原文锚点

32:L38、32:L39、33:L27；32:L38、33:L27、42:L6、42:L27；42:L6

### 镜头、时段及状态

司业青灰官服；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_zhou（中年） D-CH-036、ch_zhou/c01

### 画面内必须可见

瘦高，面少笑，下颌修齐一绺胡；补：眉梢略垂；官帽束发；补：黑发夹少许灰；半旧袍、官帽、袖摆端正；官帽，无随意添补的品级纹

### 位置、比例、遮挡和物件关系

正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Middle-aged academy administrator, 177 cm, tall, slender and erect, pale complexion, slightly drooping outer brows and a neatly trimmed tuft of beard at the chin. Black hair with a little gray secured beneath the official hat. Slightly worn blue-gray official robe, neatly arranged sleeves and hem, plain matte black official hat with no invented rank insignia. Front-facing upright natural stance, weight across both feet and toes slightly apart, head and gaze level, shoulders relaxed; both empty hands hang at his sides, fingers naturally curved. Even a newcomer sent by a prince must answer the superintendent’s routine questions. Brow tails settle, eyes look directly at the boy, lips close firmly above the tidy chin beard. Close portrait, crown to mid-thigh, subject height 1840 px, bottom anchor (512,2044). Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_zhou_p01_c01_close；主体高 1840 px，主体底边 (512,2044)，头顶至大腿中段，底边截身。

### 依赖工单ref（depends_on）

D-CH-036、D-COS-043、R-SPR-198

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
