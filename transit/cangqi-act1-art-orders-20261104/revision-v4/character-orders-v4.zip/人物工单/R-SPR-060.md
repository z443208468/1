# R-SPR-060　搭班老周 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

老周拿胳膊肘碰碰天离，像是随口问，心里已经想知道他和王府是怎么回事。疏眉一边稍抬，眼角带着细纹朝同伴瞟，嘴角轻轻收拢，留着放低声音说话的口形。

- **眉**　一侧疏眉稍抬
- **眼与视线**　斜看同伴，眼角有浅纹
- **嘴**　唇角收拢，开口很小
- **演出用途**　凑过来，打听同伴知道些什么
- **表演依据**　38:L34、38:L35、38:L37
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_laozhou_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

38

### 原文锚点

38:L34、38:L35、38:L37；38:L34、38:L37

### 镜头、时段及状态

老周门房便服；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_laozhou（成年）（D-CH-043）、ch_laozhou/c01（D-COS-050）

### 画面内必须可见

补：方圆脸、眉尾疏、眼周纹；补：暗灰头巾包着黑发；便于搬书的粗布褂，袖口可挽，裤脚束起；布腰带

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-061 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. fellow gatekeeper, softly square face, sparse brow tails, gray head wrap and compact frame practical gray-brown gatekeeper jacket, dark head wrap and cloth belt front-facing natural standing pose at eye level, relaxed shoulders, hands relaxed at sides with gently curled fingers Old Zhou makes a casual approach while fishing for inside news. One sparse brow rises, eyes glance sideways with faint creases, mouth gathers for a hushed remark.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_laozhou_p01_c01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-043、D-COS-050、R-SPR-061

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
