# R-SPR-192　张大伯 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

他忙着翻鸡，也认得这些常来打主意的孩子。平常先给一个心里有数的眼神。浓眉自然放着，目光从炉边抬起，眼尾有纹，宽口轻轻合住，暂且听人怎么说。

- **眉**　浓眉自然放平
- **眼与视线**　眼尾有纹，视线抬向孩子
- **嘴**　宽口轻闭
- **演出用途**　守着烤炉，看清凑过来的熟面孔
- **表演依据**　18:L16、18:L26
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_zhangbo_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；左手自然垂下，右手握大蒲扇（obj_pushan），扇面压在腰侧；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

衣装适用 18；状态调用见场景需求

### 原文锚点

18:L16、18:L26；18:L16、18:L26、18:L31、18:L48；18:L16

### 镜头、时段及状态

烤鸡铺围腰短衫；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_zhangbo（成年中年） D-CH-022、ch_zhangbo/c01

### 画面内必须可见

补：方脸宽口、眼窝有笑纹；补：黑发挽髻，鬓角夹灰；袖口上卷，腰间系耐脏布围腰；布带；蒲扇依动作入画

### 位置、比例、遮挡和物件关系

正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

左手自然垂下，右手握大蒲扇（obj_pushan），扇面压在腰侧

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Middle-aged roast-chicken seller, 172 cm, square face, wide mouth, laugh lines around the eyes and a sturdy medium build. Black hair in a knot, graying at the temples, oven-reddened skin. Dark ochre short shirt with rolled cuffs, smoke-dark cloth waist apron and a cloth tie. Standing front-on with weight shared across both feet and toes slightly apart, head level, shoulders relaxed. Left hand hangs freely; right hand holds the large palm-leaf fan (obj_pushan), with the fan blade resting against the side of his waist. Tending the roast, he recognizes the children who regularly try their luck. Thick brows rest, eyes lift with knowing creases, broad lips stay shut to hear them out. Close portrait, crown to mid-thigh, subject height 1840 px, bottom anchor (512,2044). Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_zhangbo_p01_c01_close；主体高 1840 px，主体底边 (512,2044)，头顶至大腿中段，底边截身。

### 依赖工单ref（depends_on）

D-CH-022、D-COS-029、R-SPR-195

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
