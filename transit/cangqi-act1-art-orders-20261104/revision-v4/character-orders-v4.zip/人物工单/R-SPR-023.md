# R-SPR-023　东宫传话侍卫 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

他跑出了一头汗，传话时仍要把差事说准确。定在他看准收话人的一眼。窄眉轻收，目光不游移，嘴角拉平，开口只留清楚吐字的小缝。

- **眉**　内眉轻收
- **眼与视线**　目光定在收话人身上
- **嘴**　唇角平，唇缝窄
- **演出用途**　在宫门交代对天离的安排
- **表演依据**　31:L7、31:L29、31:L35
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_chuanwei_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

31

### 原文锚点

31:L7、31:L29、31:L35；31:L7

### 镜头、时段及状态

东宫传令服；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_chuanwei（成年）（D-CH-034）、ch_chuanwei/c01（D-COS-041）

### 画面内必须可见

额上全是汗；补：窄眉长脸；补：黑发窄髻；东宫侍卫服色，袖口与衣襟整齐；素革带

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-024 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. messenger guard, long face, narrow eyebrows, tight black knot, light athletic build dark indigo palace escort uniform matching his unit, tidy cuffs, simple belt front-facing natural standing pose at eye level, relaxed shoulders, hands relaxed at sides with gently curled fingers Even after hurrying, the messenger takes care to address the right person. Brows narrow slightly, eyes fix on his addressee, lips part for a clear measured word.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_chuanwei_p01_c01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-034、D-COS-041、R-SPR-024

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
