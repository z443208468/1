# R-SPR-148　太学挑水栓子 · 平常

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

栓子愿意跟同伴讲自己听来的消息，说起东宫的差事，又知道这种话得压着声。眉尾略挑，眼皮先放松再微微收窄，唇角微低，只开够身边人听清的口形。

- **眉**　眉尾略挑
- **眼与视线**　眼皮自然微收
- **嘴**　唇角微低，口形小
- **演出用途**　歇下水担，私下说起当差的人事
- **表演依据**　33:L19、33:L20、33:L22、33:L23
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_shuanshui_p01_c01_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心略靠左腿，右脚只轻着地；头正，平视；维持等高，勿画成身体扭结；一手扶定直立的扁担（obj_shuanshi），一手松放，右脚少承重；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

衣装适用 33；状态调用见场景需求

### 原文锚点

33:L19、33:L20、33:L22、33:L23；33:L19、33:L22、33:L23；33:L19

### 镜头、时段及状态

挑水杂役短褂；正面自然站立；全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_shuanshui（少年） D-CH-039、ch_shuanshui/c01

### 画面内必须可见

补：细长脸、斜挑眉、唇角微低；补：黑发短束；窄袖褂，便于挑水的小裤脚；旧布鞋；扁担属场面

### 位置、比例、遮挡和物件关系

正面；重心略靠左腿，右脚只轻着地；头正，平视；维持等高，勿画成身体扭结

### 本画面可见物件：持有人｜位置｜状态

一手扶定直立的扁担（obj_shuanshi），一手松放，右脚少承重

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Adolescent academy water carrier, 155 cm, a long narrow face, slanting brows, slightly downturned lip corners and short black hair tied back. His weak right ankle takes little weight. Narrow-sleeved gray-blue coarse cloth work jacket with a faded patch where the carrying pole rests, narrow trouser hems and worn cloth shoes. Front-facing stance, head and gaze level, shoulders even, weight biased onto the left leg, right foot barely touching the ground. One hand steadies a vertical carrying pole (obj_shuanshi); the other hangs loose. He is glad to share what he has heard about the palace workers, but keeps it quiet. One brow tail lifts, easy lids narrow a touch, and slightly lowered mouth corners frame a low aside. Full figure, 1980 px high, soles at (512,2030), include head, hands and feet. Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_shuanshui_p01_c01_full；全身主体高 1980 px，足底中点 (512,2030)，完整保留头手足。

### 依赖工单ref（depends_on）

D-CH-039、D-COS-046

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
