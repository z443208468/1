# R-SPR-086　君天离之母 · 安定

**特殊状态基准　｜　待既有资料绑定**

## 这张脸为什么这样画

想把手头的活撑完，她仍想拿平日那张脸给孩子看。鬓边汗湿、脸色白里泛黄，已经泄了底。两眉仍平，下眼睑卸了些力，视线能落在面前人身上，起皮的嘴唇轻轻贴着。

- **眉**　两眉放平
- **眼与视线**　眼睑略倦，仍有落点
- **嘴**　起皮的唇轻轻合上
- **演出用途**　适用于此病程和姿势已开放的兼容状态。
- **表演依据**　5:L8、5:L47、5:L60
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_niang_p01_c01_x01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；身形细长，重心均匀；头正，平视；自然放肩，不耸肩；左手搭右手腕前，手指自然弯，指尖可见，无持物；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

05

### 原文锚点

5:L8、5:L47、5:L60；2:L5、3:L32、4:L5；1:L41、2:L5、12:L16；5:L8、5:L47

### 镜头、时段及状态

蓝布衫系围裙；正面自然站立；近景；初病强撑 鬓角汗黏，脸白里泛黄，唇干起皮；站坐尚可，保持蓝衫与围裙

### 引用的实体与设计（档案ID＋设计工单ref）

ch_niang（成年·童年篇）（已审母亲身份设定）、ch_niang/c01（D-COS-007）、ch_niang/x01（D-X-001）

### 画面内必须可见

按项目已采纳的母亲身份设计锁定脸型、眼距、眉形、眼角和唇形。；沿用项目已采纳的发色、发式、发际；1:L8写鬓边一缕散发。；家常蓝布衫外系围裙；裤装、鞋形按已有基准。；围裙系带、既有饰物与鞋履按已采纳版本。；鬓角汗黏，脸白里泛黄，唇干起皮；站坐尚可，保持蓝衫与围裙

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；身形细长，重心均匀；头正，平视；自然放肩，不耸肩

### 本画面可见物件：持有人｜位置｜状态

左手搭右手腕前，手指自然弯，指尖可见，无持物

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

已通过身份、基准及13张差分；先按实际画幅、姿势、衣装、特殊状态核配库内图。正式ID及逐图映射待导出。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Match the approved mother identity exactly in all facial proportions, brow shape, hairline, hairstyle, pigmentation and body proportions. Preserve the needle calluses. Worn blue work shirt with frayed cuffs and a waist apron; match the approved clothing reference on the apron, shoes and trousers. front-facing natural standing pose at eye level, relaxed shoulders, hands loosely together near the waist, needle calluses visible, empty hands early illness: pale sallow cheeks, dry peeling lips, one damp strand stuck at temple, still able to sit or stand She tries to look ordinary enough to keep working. Level brows, slightly tired lids still focused on the person in front of her, dry peeling lips lightly touching; damp temple hair and pale yellowish skin.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_niang_p01_c01_x01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-COS-007、D-X-001、R-SPR-090

### 优先级

待既有资料绑定｜必须

### 开工条件

母亲身份、既有基准与13张差分逐项对版
