# R-SPR-106　书阁苍青衣女子 · 平常

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

她在甬道上有礼地见过人，随后就把注意力放回那片够不着的柏枝。画她看树枝的专心。眉舒平，眼睛往枝头轻轻抬，唇角安静放着，脸上的兴趣随视线走。

- **眉**　眉梢舒平
- **眼与视线**　目光轻抬，看向枝头
- **嘴**　唇角自然放平
- **演出用途**　见礼后将注意力转回够不着的柏枝
- **表演依据**　38:L31
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_qingnv_p01_c01_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双臂拢着两卷书（obj_beishu），书卷置于胸下不挡脸；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

38（套装定版／标准基准）

### 原文锚点

38:L31

### 镜头、时段及状态

苍青衫白玉簪；正面自然站立；站立全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_qingnv（少年或青年）（D-CH-042）、ch_qingnv/c01（D-COS-049）、obj_beishu（随承载画面绘制）

### 画面内必须可见

补：鹅蛋脸、小而圆的鼻尖；素白玉簪；补：以低髻别牢；苍青色衣裳，身上不饰繁复花样；一支白玉簪，无其余首饰

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双臂拢着两卷书（obj_beishu），书卷置于胸下不挡脸

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。本张与身份、衣装合并提交角色定版。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. young woman with oval face, softly rounded nose and a low black bun secured by one plain white jade pin quiet blue-green robe, single plain white jade hairpin, no other jewelry front-facing natural standing pose at eye level, relaxed shoulders, cradle two rolled texts below the chest, unobstructed face After her greeting, her attention returns to the cypress sprig just out of reach. Brows rest smooth, eyes lift gently toward the branch, relaxed lips stay level.. Full length from head to soles, feet at (512,2030), complete hands, feet and costume inside clear margins. Subject height 1980 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_qingnv_p01_c01_full；脚底锚点 (512,2030)，主体高 1980 px，四边留空；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-042、D-COS-049

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
