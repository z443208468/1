# R-SPR-053　井边洗衣妇 · 平常

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

她会看一眼陌生孩子的来路，也肯给他喝水、塞半块馍。定在她看清人的那一刻。眉头轻轻松开，目光在孩子脸上停一下，闭着的唇保持自然，没等对方说感激的话。

- **眉**　眉头微松
- **眼与视线**　打量的目光停在孩子脸上
- **嘴**　唇放松闭合
- **演出用途**　井边看清背剑的孩子，再伸手帮人
- **表演依据**　20:L32、20:L42、20:L53
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_jingnv_p01_c01_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

20（套装定版／标准基准）

### 原文锚点

20:L32、20:L42、20:L53；20:L32

### 镜头、时段及状态

洗衣围裙；正面自然站立；站立全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_jingnv（成年）（D-CH-028）、ch_jingnv/c01（D-COS-035）

### 画面内必须可见

补：细眉、小鼻梁、圆下巴；补：黑发盘低，以窄布束；小袖工作衫、长裤，腰前系围裙；布鞋

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。本张与身份、衣装合并提交角色定版。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. adult well-side washerwoman, fine brows, rounded chin and low-bound black hair, sun-touched skin, strong forearms muted plum work shirt, worn beige apron and cloth shoes front-facing natural standing pose at eye level, relaxed shoulders, hands relaxed at sides with gently curled fingers She takes a moment to judge the young stranger before helping him. Brows ease, gaze rests briefly on the boy, lips stay naturally closed; quiet, practical kindness.. Full length from head to soles, feet at (512,2030), complete hands, feet and costume inside clear margins. Subject height 1980 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_jingnv_p01_c01_full；脚底锚点 (512,2030)，主体高 1980 px，四边留空；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-028、D-COS-035

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
