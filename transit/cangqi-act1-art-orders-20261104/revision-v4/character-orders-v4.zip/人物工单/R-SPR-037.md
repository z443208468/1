# R-SPR-037　靖王府黑脸护从 · 平常

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

一见马逼近，他比同伴先挡上去，脸上先有了要把人拦住的意思。浓眉压平，目光钉住来路，嘴角收住、下颌微绷，像这一步站稳了就不肯让。

- **眉**　浓眉低平
- **眼与视线**　看定来路
- **嘴**　唇角收住，下颌略绷
- **演出用途**　先迎上来替世子挡马
- **表演依据**　27:L6
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_heilian_p01_c01_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；一手自然垂下，一手停在佩刀鞘（obj_huchongdao）旁，不拔刀；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

27、28（套装定版／标准基准）

### 原文锚点

27:L6；27:L4、27:L6、28:L20、28:L25；25:L28、27:L6

### 镜头、时段及状态

靖王府护从服；正面自然站立；站立全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_heilian（成年）（D-CH-033）、ch_heilian/c01（D-COS-040）、obj_huchongdao（随承载画面绘制）

### 画面内必须可见

脸黑；补：浓眉方下颌；不把另一人的旧疤移到他脸上；补：黑发高束；挺括短衣、窄袖、皮带佩长刀；长刀及铜件鞘（obj_huchongdao）

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

一手自然垂下，一手停在佩刀鞘（obj_huchongdao）旁，不拔刀

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。本张与身份、衣装合并提交角色定版。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. dark-complexioned household guard, full brows, wide square jaw, no facial scar, bound black hair and strong shoulders structured deep teal guard tunic, belt, long blade in brass-mounted scabbard front-facing natural standing pose at eye level, relaxed shoulders, one hand near sheathed long saber, other lowered First to block the approaching horse, he holds the line. Thick brows level and low, eyes fixed on the approach, corners firm and jaw braced.. Full length from head to soles, feet at (512,2030), complete hands, feet and costume inside clear margins. Subject height 1980 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_heilian_p01_c01_full；脚底锚点 (512,2030)，主体高 1980 px，四边留空；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-033、D-COS-040

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
