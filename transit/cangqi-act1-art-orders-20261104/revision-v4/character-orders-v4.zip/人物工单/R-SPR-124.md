# R-SPR-124　邻家婶子 · 利落

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

手上沾着水，听清孩子的话，她把米盆一搁就有了主意。粗平眉舒展，目光正看着孩子，宽嘴自然合拢，脸上是应了一声便能去办事的踏实。

- **眉**　粗平眉放松
- **眼与视线**　眼神直，眼皮舒展
- **嘴**　自然合口
- **演出用途**　搁下米盆、答应帮忙，把孩子当下的事接过来
- **表演依据**　6:L59、6:L60
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_shenzi_p01_c01_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；腰板厚实，重心落稳；头正，平视；两肩略开；双臂近身放下，双手微张，掌厚，不持物；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

05–06解下前、09、11–12（套装定版／标准基准）

### 原文锚点

6:L59、6:L60；5:L55、5:L58、11:L18、12:L11；6:L59、12:L5、12:L11

### 镜头、时段及状态

邻家日用围裙装；正面自然站立；站立全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_shenzi（成年·村中）（D-CH-005）、ch_shenzi/c01（D-COS-009）

### 画面内必须可见

补：宽鼻梁、丰颊、厚平眉；补：黑发厚髻，以深布束；布衫、长裤、半身围裙，系带宽；围裙角可攥；脚穿布鞋

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；腰板厚实，重心落稳；头正，平视；两肩略开

### 本画面可见物件：持有人｜位置｜状态

双臂近身放下，双手微张，掌厚，不持物

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。本张与身份、衣装合并提交角色定版。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. tall sturdy village woman, broad waist and cheeks, strong flat brows, wide nose bridge, black hair in a thick cloth-tied bun, weathered warm complexion muted olive-brown work shirt, faded ocher apron, dark trousers and cloth shoes front-facing natural standing pose at eye level, relaxed shoulders, steady arms resting at sides, broad open hands She sets aside her own work as soon as she understands the child. Thick brows at ease, direct unflustered eyes, broad mouth resting closed after a short answer.. Full length from head to soles, feet at (512,2030), complete hands, feet and costume inside clear margins. Subject height 1980 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_shenzi_p01_c01_full；脚底锚点 (512,2030)，主体高 1980 px，四边留空；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-005、D-COS-009

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
