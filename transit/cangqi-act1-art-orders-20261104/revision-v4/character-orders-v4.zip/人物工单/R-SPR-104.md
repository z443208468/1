# R-SPR-104　君天离之母 · 遗容静态基准

**特殊状态基准　｜　待既有资料绑定**

## 这张脸为什么这样画

此处画床上遗容。眉毛随额头自然静置，双眼完全闭合，眼皮无张力；面颊松塌，嘴微开，唇缘静止，热病的红潮已退。床上的头位沿用本组基准。门板上只露脸、白布覆面的后续镜头各按对应场次处理。

- **眉**　双眉在额头自然静置
- **眼与视线**　双眼闭合，睑无张力
- **嘴**　嘴微开、唇缘静止
- **演出用途**　遗容静态母版，床上场次适用。
- **表演依据**　10:L13–L15、10:L31、10:L34、11:L20、11:L23
- **调用**　遗容只按此处的静态描述制作。

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_niang_p03_c02_x03_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

倚卧；卧床休息、重症及静止遗容；仅近景；靠垫支起上背约30度；侧身朝画面左，不做水平通幅躺姿；头略侧，颈放松；肩低而内收，上背放松；一手松落身侧，一手靠腹部，手指软；被褥与床由场景负责；不为递物、收剑或抓捕做连续动作帧；头顶至大腿中段；近景主体高1840，主体底边(512,2044)

### 涉及场次

10、11

### 原文锚点

10:L13–L15、10:L31、10:L34、11:L20、11:L23；5:L62、8:L4、10:L34；5:L59、5:L62、10:L34、11:L20、12:L16；10:L15、10:L31、10:L34、11:L20、11:L23

### 镜头、时段及状态

蓝布衫去围裙；倚卧；近景；离世后静卧 闭眼无眼动，嘴微开、面颊塌、头及发丝松散；静止，无呼吸动效

### 引用的实体与设计（档案ID＋设计工单ref）

ch_niang（成年·童年篇）（已审母亲身份设定）、ch_niang/c02（D-COS-008）、ch_niang/x03（D-X-003）

### 画面内必须可见

按项目已采纳的母亲身份设计锁定脸型、眼距、眉形、眼角和唇形。；沿用项目已采纳的发色、发式、发际；1:L8写鬓边一缕散发。；以磨边蓝布衫为底衣；当前卧床组合规划移除围裙。被褥另由场景承载。；沿用既有款式的配饰。；闭眼无眼动，嘴微开、面颊塌、头及发丝松散；静止，无呼吸动效

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。靠垫支起上背约30度；侧身朝画面左，不做水平通幅躺姿；头略侧，颈放松；肩低而内收，上背放松

### 本画面可见物件：持有人｜位置｜状态

一手松落身侧，一手靠腹部，手指软；被褥与床由场景负责

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

已通过身份、基准及13张差分；先按实际画幅、姿势、衣装、特殊状态核配库内图。正式ID及逐图映射待导出。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Match the approved mother identity, hairline, facial proportions and bed clothing. Use the established recumbent pose in its locked framing. Still features after death in the bed: brows at rest, eyelids completely closed with no muscular tension, cheeks slack, lips slightly parted and motionless, fever flush gone. Static body and head. Close crop, same scale and anchors as the approved state, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_niang_p03_c02_x03_close；主体底边 (512,2044)，主体高 1840 px。取景 头顶至大腿中段；近景主体高1840，主体底边(512,2044)；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-COS-008、D-X-003、R-SPR-090

### 优先级

待既有资料绑定｜必须

### 开工条件

母亲身份、既有基准与13张差分逐项对版
