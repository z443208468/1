# R-SPR-009　疤脸 · 沉着

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

疤脸认生人，罐边的孩子还等他分吃的。他得先听明白来人是谁，眉就平平压着，上眼皮半盖，目光落得稳。唇合拢等对方说话，左颊的疤跟着脸安静下来。

- **眉**　两眉低平
- **眼与视线**　上眼皮略盖眼瞳，凝视来人
- **嘴**　嘴唇轻合，左颊疤不牵动
- **演出用途**　分汤时停下来认新面孔
- **表演依据**　14:L4、14:L9
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_balian_p02_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

庙中坐守；守火分食、靠墙歇病；仅近景；坐低，上身向画面左转一点，膝头靠近；头稍低，眼能看清；肩内收，背略弯；前臂靠近膝头，两手空着；不固定盛汤、拨灰的瞬态；不为递物、收剑或抓捕做连续动作帧；头顶至大腿中段；近景主体高1840，主体底边(512,2044)

### 涉及场次

14（同组派生基准）

### 原文锚点

14:L4、14:L9；14:L4、14:L22、15:L7；14:L4、14:L45

### 镜头、时段及状态

庙童旧褂；庙中坐守；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_balian（童年·破庙初见）（D-CH-008）、ch_balian/c01（D-COS-013）

### 画面内必须可见

脸有疤；补：固定为左颊斜向一道浅色旧疤、方下巴；补：黑发在后颈扎小结；敞腕旧短褂配窄长裤；布绳，无金属扣

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。坐低，上身向画面左转一点，膝头靠近；头稍低，眼能看清；肩内收，背略弯

### 本画面可见物件：持有人｜位置｜状态

前臂靠近膝头，两手空着；不固定盛汤、拨灰的瞬态

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-002 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. older street child, a single pale diagonal scar on left cheek, square chin, hooded eyes, black hair tied at the nape, thin lanky frame iron-brown ragged child's jacket, narrow long trousers and rope ties low seated older street boy with bent knees, forward shoulders, forearms resting close to knees, empty hands The boy tending the food pauses to size up a newcomer. Low level brows, hooded steady eyes, mouth quietly shut, left cheek scar at rest.. Follow the exact body pose and crop specified above. Keep subject height 1840 px and bottom anchor (512,2044). Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_balian_p02_c01_close；主体底边 (512,2044)，主体高 1840 px。取景 头顶至大腿中段；近景主体高1840，主体底边(512,2044)；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-008、D-COS-013、R-SPR-002

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
