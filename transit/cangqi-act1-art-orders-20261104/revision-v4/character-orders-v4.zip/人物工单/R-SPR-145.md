# R-SPR-145　靖王世子 · 从容

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

世子一向有人护着，还没开口就觉得事会照他的意思办。修齐的眉舒着，眼皮略沉，嘴角像生来便带一点钩。让这点有恃无恐在安静时也看得出。

- **眉**　修齐的眉舒展
- **眼与视线**　眼皮略沉
- **嘴**　一边唇角自然微勾
- **演出用途**　初从车帘后探脸，等旁人让路
- **表演依据**　26:L5
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_shizi_p02_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

车内斜倚；挑帘后的长段讥讽，拖出前的末个安坐节点；仅近景；身侧倚，重心后撤；画面侧面为靠背方向；下巴微抬；肩放松、稍往后靠；前臂搁低，腕钏可见；不画车窗、帘或固定手柄；不为递物、收剑或抓捕做连续动作帧；头顶至大腿中段；近景主体高1840，主体底边(512,2044)

### 涉及场次

26

### 原文锚点

26:L5；26:L8、26:L13、27:L12；26:L5、27:L14、27:L17、27:L18

### 镜头、时段及状态

世子锦袍；车内斜倚；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_shizi（青年·二十来岁） D-CH-015、ch_shizi/c01

### 画面内必须可见

白里透红，修齐眉毛，嘴角素来上勾；束发戴冠；补：黑发、发冠居正；锦袍覆盖月白中衣，发冠正束，袖口露手镯；腕钏、发冠；衣身破损交给x01

### 位置、比例、遮挡和物件关系

身侧倚，重心后撤；画面侧面为靠背方向；下巴微抬；肩放松、稍往后靠

### 本画面可见物件：持有人｜位置｜状态

前臂搁低，腕钏可见；不画车窗、帘或固定手柄

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Young nobleman in his twenties, 174 cm, fair skin with a rosy cast, groomed brows and naturally upturned lip corners. Medium build, pale wrists, black hair tied into a centered formal crown in the intact state. Glossy burgundy-purple brocade robe with narrow subdued patterns over a moon-white inner robe, wrist bangle visible at the cuff and a formal hair crown. Tears and disarray apply only to the designated special-state variant. Seated, reclining sideways with weight shifted back in the direction of the seat support, chin slightly raised, shoulders relaxed and leaning back. Forearm rests low with bangle visible; no carriage window, curtain or handle. Protected from consequences, the young lord expects others to move. Groomed brows rest smooth, lids hang a little heavy, one mouth corner sits in its habitual hook. Close portrait, crown to mid-thigh, subject height 1840 px, bottom anchor (512,2044). Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_shizi_p02_c01_close；主体高 1840 px，主体底边 (512,2044)，头顶至大腿中段，底边截身。

### 依赖工单ref（depends_on）

D-CH-015、D-COS-022、R-SPR-144

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
