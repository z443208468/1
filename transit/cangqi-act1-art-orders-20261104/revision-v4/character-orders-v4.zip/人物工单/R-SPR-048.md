# R-SPR-048　东宫小黄门 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

他只是来送纸笔，陌生人却要他代传话。他习惯先守住当差的分寸。细眉横着，眼皮略抬起打量对方，嘴角往里收。嘴唇微微开一道，够压低声音回话。

- **眉**　细眉横平
- **眼与视线**　从眼皮下审视对方
- **嘴**　唇角内收，唇缝小
- **演出用途**　送文具时听到托他向太子问安
- **表演依据**　33:L14、33:L15、33:L17
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_huangmen_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双臂抱住纸笔书册（obj_donggongzhi），肩平，不做递送动作；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

33

### 原文锚点

33:L14、33:L15、33:L17；33:L14、33:L17；33:L14

### 镜头、时段及状态

东宫内役服；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_huangmen（少年后期）（D-CH-038）、ch_huangmen/c01（D-COS-045）、obj_donggongzhi（随承载画面绘制）

### 画面内必须可见

下巴尖，拿眼皮夹人；补：窄面、细眉、薄唇；补：宫役小帽束发；合体小袖长衣，书册由手另持；低帽

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双臂抱住纸笔书册（obj_donggongzhi），肩平，不做递送动作

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-049 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. young palace attendant only a few years older than Tianli, pointed chin, narrow face, thin straight brows, plain small cap muted tea-green palace service robe, narrow sash and low dark cap front-facing natural standing pose at eye level, relaxed shoulders, both forearms support stacked paper and books at waist-to-chest height A request to carry a personal greeting makes him guard the limits of his errand. Brows level, eyes appraise from under the lids, mouth corners draw in and lips barely part.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_huangmen_p01_c01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-038、D-COS-045、R-SPR-049

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
