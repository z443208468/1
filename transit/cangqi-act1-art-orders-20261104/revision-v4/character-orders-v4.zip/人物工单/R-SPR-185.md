# R-SPR-185　萧原 · 平静

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

当场要稳住局面，他一句短话就够，旁人从他脸上看不出急。低直眉平放，窄眼稳稳朝前，双唇自然合上，像已经把该说的说完，还在留心四周。

- **眉**　低直眉平放
- **眼与视线**　窄眼稳
- **嘴**　唇自然合
- **演出用途**　止住眼前的人，省话而留神
- **表演依据**　40:L27
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_xiaoyuan_p01_c01_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心稳，身材高；头正，平视；肩平，脊背挺直；大手空掌垂下，手背线条清楚；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

衣装适用 40–43；状态调用见场景需求

### 原文锚点

40:L27；40:L21、40:L26、40:L27、42:L34、43:L28、43:L55；40:L21、43:L28、43:L55、43:L57

### 镜头、时段及状态

深色学衣与兽皮护膝；正面自然站立；全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_xiaoyuan（少年·太学同窗） D-CH-020、ch_xiaoyuan/c01

### 画面内必须可见

补：长方脸、低直眉、眼皮较窄；补：黑发束高，发尾短而收拢；深色便服，袍摆能覆膝，内系兽皮护膝；护膝绑带平时系好；松脱与重系留给特写（obj_huxi）

### 位置、比例、遮挡和物件关系

正面；重心稳，身材高；头正，平视；肩平，脊背挺直

### 本画面可见物件：持有人｜位置｜状态

大手空掌垂下，手背线条清楚

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Tall adolescent male academy student, 168 cm, rectangular face, low straight brows and narrow eyelids. Black hair tied high with short gathered ends; broad, substantial hands. Dark blue-black informal student robe with a hem long enough to cover the knees; a pair of brown hide knee guards with pale worn edges and normally secured ties beneath the robe. Front-facing, tall and steady, head level and eyes forward, shoulders even and back straight. Both large empty hands hang down, backs of the hands clearly shaped. He steadies a tense moment with few words. Rest the low straight brows, hold the narrow eyes steady ahead, let both lips close naturally while he stays attentive. Full figure, 1980 px high, soles at (512,2030), include head, hands and feet. Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_xiaoyuan_p01_c01_full；全身主体高 1980 px，足底中点 (512,2030)，完整保留头手足。

### 依赖工单ref（depends_on）

D-CH-020、D-COS-027

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
