# R-SPR-094　君天离之母 · 安定

**近景基准　｜　待既有资料绑定**

## 这张脸为什么这样画

儿子紧盯着她的脸，想从脸上先读出答案。她留心他听懂了多少，越碰上不好答的话，声音和面色越平。定在她看回来的一刻，眉弧松开，眼皮自然搭着而瞳仁有落点，两唇轻合，像还给孩子留着下一问。

- **眉**　眉在原有弧度上放松
- **眼与视线**　眼睑放松仍有焦点
- **嘴**　嘴唇轻合
- **演出用途**　听孩子追问时稳住神色，给他接话的余地。
- **表演依据**　1:L28
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_niang_p02_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

端坐守家／病中倚坐；坐着同孩子谈话，病中坐起听答；仅近景；半身略向画面左，髋部后坐；平视略垂下巴；肩斜度小，背部可依靠既有环境；两手松搭膝前；不拿针、剑、药碗，不画凳床；不为递物、收剑或抓捕做连续动作帧；头顶至大腿中段；近景主体高1840，主体底边(512,2044)

### 涉及场次

01、04

### 原文锚点

1:L28；1:L3、1:L55、7:L27、9:L22；1:L41、2:L5、12:L16

### 镜头、时段及状态

蓝布衫系围裙；端坐守家／病中倚坐；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_niang（成年·童年篇）（已审母亲身份设定）、ch_niang/c01（D-COS-007）

### 画面内必须可见

按项目已采纳的母亲身份设计锁定脸型、眼距、眉形、眼角和唇形。；沿用项目已采纳的发色、发式、发际；1:L8写鬓边一缕散发。；家常蓝布衫外系围裙；裤装、鞋形按已有基准。；围裙系带、既有饰物与鞋履按已采纳版本。

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。半身略向画面左，髋部后坐；平视略垂下巴；肩斜度小，背部可依靠既有环境

### 本画面可见物件：持有人｜位置｜状态

两手松搭膝前；不拿针、剑、药碗，不画凳床

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

已通过身份、基准及13张差分；先按实际画幅、姿势、衣装、特殊状态核配库内图。正式ID及逐图映射待导出。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Match the approved mother identity exactly in all facial proportions, brow shape, hairline, hairstyle, pigmentation and body proportions. Preserve the needle calluses. Worn blue work shirt with frayed cuffs and a waist apron; match the approved clothing reference on the apron, shoes and trousers. seated three-quarter pose, gaze slightly lowered, hands loosely in lap, no furniture or tools painted into sprite Attentive maternal stillness. Let the approved brow arch rest, lids easy, pupils quietly focused on the listener, lips touching without pressure. She leaves room for the child to ask again.. Follow the exact body pose and crop specified above. Keep subject height 1840 px and bottom anchor (512,2044). Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_niang_p02_c01_close；主体底边 (512,2044)，主体高 1840 px。取景 头顶至大腿中段；近景主体高1840，主体底边(512,2044)；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-COS-007、R-SPR-090

### 优先级

待既有资料绑定｜必须

### 开工条件

母亲身份、既有基准与13张差分逐项对版
