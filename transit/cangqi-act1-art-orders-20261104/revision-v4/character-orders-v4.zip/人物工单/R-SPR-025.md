# R-SPR-025　拔刀递食的东宫侍卫 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

方才斥责天离的话才咽回去，如今轮到他送吃的。他服从差遣，气却还没全消。厚眉拧着，眼睛正看天离，嘴唇绷得整整齐齐，把该办的差事先办完。

- **眉**　厚眉仍轻拧
- **眼与视线**　正视天离，眼神绷着
- **嘴**　唇线抿得齐整
- **演出用途**　奉命送食物，脸上还带着前番不快
- **表演依据**　23:L3、24:L16
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_dongwei_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；手自然下垂；腰佩有鞘刀（obj_weidao），基准不拔刀；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

24

### 原文锚点

23:L3、24:L16；22:L49、23:L3、24:L16；22:L25、24:L16

### 镜头、时段及状态

东宫随车武服；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_dongwei（成年）（D-CH-030）、ch_dongwei/c01（D-COS-037）、obj_weidao（随承载画面绘制）

### 画面内必须可见

拧眉、脸涨红；补：国字脸、较厚眉；补：黑发扎成紧髻；短外褂束腰、窄袖便于执刀、长靴；鞘刀贴腰，刀只在冲撞段出鞘（obj_weidao）

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

手自然下垂；腰佩有鞘刀（obj_weidao），基准不拔刀

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-027 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. guard with a broad square face, thick contracted brows, black topknot, strong shoulders and tan skin muted indigo escort uniform, close sleeves, plain leather belt, sheathed sidearm and boots front-facing natural standing pose at eye level, relaxed shoulders, hands lowered, sidearm sheathed at waist The guard brings food despite his lingering annoyance. Thick brows remain knitted, gaze faces the boy straight on, lips make a taut even line of obedience.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_dongwei_p01_c01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-030、D-COS-037、R-SPR-027

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
