# R-SPR-182　王大姐 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

她做惯摊前的生意，听到问馅的声音，转头便能报出来。短眉一抬，眼睛又快又准地接住问话的人，嘴唇微分，清清楚楚送出头一个字。

- **眉**　短眉微抬
- **眼与视线**　眼睛有神，迎住问话人
- **嘴**　嘴唇微分，口形利落
- **演出用途**　蒸笼前听见人问今天什么馅
- **表演依据**　18:L5、18:L8、18:L9
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_wangjie_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

18

### 原文锚点

18:L5、18:L8、18:L9；18:L5

### 镜头、时段及状态

包子摊家常装；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_wangjie（成年） D-CH-023、ch_wangjie/c01

### 画面内必须可见

圆脸、胖乎乎；补：短直眉；补：黑发以布包成髻；大襟窄袖上衣配半身围腰，肩搭擦汗的巾；肩巾

### 位置、比例、遮挡和物件关系

正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Adult steamed-bun seller, 160 cm, plump round face and build, short straight brows, sturdy forearms, heat perspiration on the forehead. Black hair wrapped in cloth around a bun. Light brown coarse woven narrow-sleeved wrap-front top, half-length waist apron, rice-gray sweat cloth draped over one shoulder. Front-facing natural stance, weight on both feet with toes slightly apart, head and gaze level, shoulders loose; both empty hands hang by her sides with fingers naturally curved. She can answer a question about the filling the instant she hears it. Short brows perk up, bright eyes meet the customer, lips part for a brisk clear reply. Close portrait, crown to mid-thigh, subject height 1840 px, bottom anchor (512,2044). Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_wangjie_p01_c01_close；主体高 1840 px，主体底边 (512,2044)，头顶至大腿中段，底边截身。

### 依赖工单ref（depends_on）

D-CH-023、D-COS-030、R-SPR-183

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
