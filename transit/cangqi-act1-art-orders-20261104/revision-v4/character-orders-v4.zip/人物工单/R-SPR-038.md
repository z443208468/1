# R-SPR-038　团扇红裙女子 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

她在门前见惯人来人往，打量也带着一副招呼人的笑。把弯眉舒着，眼睛停在来人脸上，嘴角轻扬一点，像随时可以接一句客气话。

- **眉**　弯眉舒展
- **眼与视线**　长眼含笑，落在来人脸上
- **嘴**　两侧嘴角轻扬
- **演出用途**　站在阶前打量过路人
- **表演依据**　34:L9、34:L10
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_hongqun_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；右手执团扇（obj_tuanshan）垂于腰侧，扇面不遮脸；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

34（同组派生基准）

### 原文锚点

34:L9、34:L10；34:L9、34:L10、34:L12；34:L10

### 镜头、时段及状态

簪花红裙；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_hongqun（青年）（D-CH-040）、ch_hongqun/c01（D-COS-047）、obj_tuanshan（随承载画面绘制）

### 画面内必须可见

笑吟吟；补：弯眉、长眼；鬓边簪花；补：高髻乌发；红裙、轻便上衣，发侧簪一朵花；鬓花、团扇

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

右手执团扇（obj_tuanshan）垂于腰侧，扇面不遮脸

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-040 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. young woman with curved brows, long eyes and a flower in her black updo, slender frame red skirt, pale apricot bodice, flower at the temple, round fan front-facing natural standing pose at eye level, relaxed shoulders, round fan lowered at right waist, face unobstructed At ease greeting people on the steps, she gives the passerby an easy look. Curved brows relax, gaze settles openly on him, lip corners lift in a small greeting.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_hongqun_p01_c01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-040、D-COS-047、R-SPR-040

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
