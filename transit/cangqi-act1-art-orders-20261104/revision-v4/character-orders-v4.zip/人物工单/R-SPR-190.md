# R-SPR-190　张记药铺老人 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

药铺老人经手过不少着急的人家，越是对方急，他越要听清了才好抓药。老眉顺平，细眼专注在说话的人身上，唇放松合着，等听明白再交代下一步。

- **眉**　老眉自然顺平
- **眼与视线**　细眼凝神，注视说话人
- **嘴**　唇放松合拢
- **演出用途**　柜后听清病况，再称药
- **表演依据**　7:L5、7:L6
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_yaolao_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；细长手指松搭腰前，掌空；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

07

### 原文锚点

7:L5、7:L6；7:L5

### 镜头、时段及状态

药铺老人工作衣；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_yaolao（老人） D-CH-021、ch_yaolao/c01

### 画面内必须可见

老年；补：长眉、细眼、眶下浅纹；补：灰发小髻；长衫收袖，衣摆过膝，裤脚干净；素腰带

### 位置、比例、遮挡和物件关系

正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

细长手指松搭腰前，掌空

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Elderly apothecary, 162 cm, long brows, narrow eyes, fine lines under the eyes, gray hair in a small knot, narrow shoulders and pronounced finger joints. Tea-gray working robe falling below the knees, gathered sleeves with light brown cuff edging, clean trouser hems and a plain waist sash. Standing front-on with weight shared across both feet and toes slightly apart, head level, eyes forward, shoulders easy. Long fine fingers rest loosely in front of his waist, empty palms. An experienced dispenser lets an anxious visitor finish before weighing the medicine. Smooth aged brows, narrow attentive eyes on the speaker, lips relaxed together while listening. Close portrait, crown to mid-thigh, subject height 1840 px, bottom anchor (512,2044). Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_yaolao_p01_c01_close；主体高 1840 px，主体底边 (512,2044)，头顶至大腿中段，底边截身。

### 依赖工单ref（depends_on）

D-CH-021、D-COS-028、R-SPR-191

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
