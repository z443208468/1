# R-SPR-031　编草茎的小女孩 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

她把被卖的经历说得像讲今天吃了什么。要让人看见这孩子已经能把这件事平平说出口。细眉舒展，双眼朝前，唇放松合起，在说完的一刻歇住。

- **眉**　细眉舒平
- **眼与视线**　双眼自然朝前，眼圈平常
- **嘴**　小嘴松松合住
- **演出用途**　平淡地讲母亲把自己卖了
- **表演依据**　16:L5、16:L16、16:L18
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_guniang_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；两手在腹前松拢，隐约露出一根草茎（obj_caojing），不演哭态；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

16（套装定版／标准基准）

### 原文锚点

16:L5、16:L16、16:L18；16:L5、16:L12、16:L14、16:L16；16:L5

### 镜头、时段及状态

草茎女孩旧衣；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_guniang（童年）（D-CH-025）、ch_guniang/c01（D-COS-032）、obj_caojing（随承载画面绘制）

### 画面内必须可见

下巴尖；补：眼距稍宽；补：短发用褪色布条束住；宽旧短上衣，细胳膊从大袖口探出；布带

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

两手在腹前松拢，隐约露出一根草茎（obj_caojing），不演哭态

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-032 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. thin young girl, pointed chin, slightly wide-set eyes, tied short black hair, muddy marks on the backs of her hands oversized earth-gray tunic and thin cloth hair tie front-facing natural standing pose at eye level, relaxed shoulders, small hands holding one fine grass stem before the waist She recounts being sold with the everyday cadence of talking about a meal. Unfurrowed brows, forward dry eyes, small lips resting together after the sentence.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_guniang_p01_c01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-025、D-COS-032、R-SPR-032

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
