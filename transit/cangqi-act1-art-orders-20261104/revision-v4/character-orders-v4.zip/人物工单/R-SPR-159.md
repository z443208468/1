# R-SPR-159　太常 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

太常到了跟前，先看屋顶的破口、被砸的桌子，才来认天离。他处理事情惯于把眼前情形看全。平直的眉不急着皱，目光沉稳地落到人脸上，嘴合着把发话留到后头。

- **眉**　眉平而直
- **眼与视线**　看准人，目光沉稳
- **嘴**　嘴自然合拢
- **演出用途**　看过讲堂破口与书案，再来看人
- **表演依据**　42:L21、42:L25
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_taichang_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

42

### 原文锚点

42:L21、42:L25；42:L21、42:L24、42:L26；42:L21、42:L24

### 镜头、时段及状态

太常深青袍；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_taichang（成年官员） D-CH-041、ch_taichang/c01

### 画面内必须可见

笑意堆出；补：宽额、平眼角、唇薄；补：深色冠束发；深青长袍，袖可拢手；补：深冠、素靴

### 位置、比例、遮挡和物件关系

正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Adult court official, 174 cm, broad forehead, level eye corners, thin lips, evenly proportioned build and an especially upright back. Hair secured with a dark formal cap. Deep teal long official robe with sleeves wide enough to gather the hands, narrow dark collar edging, dark formal cap and plain boots. Standing front-on, head level and eyes forward, back upright, shoulders relaxed, weight across both feet with toes slightly apart. Both empty hands hang by his sides with naturally curved fingers. The official surveys the broken roof and damaged desk before judging the boy. Straight level brows, a measured gaze finally settling on him, mouth closed while he takes things in. Close portrait, crown to mid-thigh, subject height 1840 px, bottom anchor (512,2044). Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_taichang_p01_c01_close；主体高 1840 px，主体底边 (512,2044)，头顶至大腿中段，底边截身。

### 依赖工单ref（depends_on）

D-CH-041、D-COS-048、R-SPR-161

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
