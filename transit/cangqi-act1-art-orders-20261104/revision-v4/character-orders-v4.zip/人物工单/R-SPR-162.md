# R-SPR-162　轩辕灵澈 · 平和

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

递出油纸包时，他知道一个孩子正提防着自己，便给对方一点自己决定的工夫。这张平常脸要让人敢接近，淡眉舒开，长眼平视，注意力在孩子身上，唇线松而完整，嘴角没有居高临下的笑。

- **眉**　淡眉自然舒展
- **眼与视线**　长眼平静聚焦
- **嘴**　唇线放松
- **演出用途**　递食物时的平和，给孩子自己接过来的余地。
- **表演依据**　23:L17
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_taizi_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心居中，双脚不叉开；头正，平视；挺背，肩部自然放下；双手规整垂在身侧；掌指不握拳；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

衣装适用 22–31；状态调用见场景需求

### 原文锚点

23:L17；22:L24、23:L12、29:L18、31:L33；22:L24、23:L4、29:L6

### 镜头、时段及状态

车驾暗纹常服；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_taizi（童年后期·车驾相遇） D-CH-013、ch_taizi/c01

### 画面内必须可见

脸白净，眉眼淡；补：长眼、匀细眉、鼻梁挺直；补：黑发拢成端正小髻；合身的干净长衣；领口暗纹、袖口滚银边；极细银线滚边、素带

### 位置、比例、遮挡和物件关系

正面；重心居中，双脚不叉开；头正，平视；挺背，肩部自然放下

### 本画面可见物件：持有人｜位置｜状态

双手规整垂在身侧；掌指不握拳

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Young crown prince at the carriage meeting, 137 cm, fair skin, faint evenly fine brows, long eyes and straight nose bridge. Narrow shoulders and black hair in a neat small knot. Clean fitted long robe in subdued deep blue-black figured weave, discreet woven collar pattern, fine silver edging at the cuffs and a plain sash. Standing front-on with centered weight, feet set close, head level, gaze forward, back erect and shoulders down. Both empty hands hang neatly by his sides, fingers uncurled. Offering the child time to decide. Faint brows relaxed, long eyes level and attentive, lips softly together with neutral corners; quietly approachable. Close portrait, crown to mid-thigh, subject height 1840 px, bottom anchor (512,2044). Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_taizi_p01_c01_close；主体高 1840 px，主体底边 (512,2044)，头顶至大腿中段，底边截身。

### 依赖工单ref（depends_on）

D-CH-013、D-COS-019、R-SPR-163

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
