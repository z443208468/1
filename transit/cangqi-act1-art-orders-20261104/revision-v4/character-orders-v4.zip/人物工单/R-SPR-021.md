# R-SPR-021　太子车夫 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

这车夫看孩子试了也上不去，便伸手托一把。他的好意落在等稳这一刻。眉头放松，眼睛看孩子踩马镫的地方，嘴轻轻闭住，留出对方自己试的工夫。

- **眉**　两眉自然放松
- **眼与视线**　目光落向孩子找马镫的位置
- **嘴**　双唇轻合
- **演出用途**　看天离踩空马镫，准备托他上马
- **表演依据**　24:L33、24:L35、24:L36
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_chafu_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

24

### 原文锚点

24:L33、24:L35、24:L36；24:L33、24:L36、26:L12；24:L33

### 镜头、时段及状态

车夫束袖短衣；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_chafu（成年）（D-CH-031）、ch_chafu/c01（D-COS-038）

### 画面内必须可见

补：阔额、眼尾有细纹；补：深色布巾包发；小袖便服，腰侧可挂马具；素巾，无官饰

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-022 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. working driver with broad forehead, creased eyes, dark hair wrap and work-worn hands dust-brown driver's short tunic, cloth headwrap, worn belt front-facing natural standing pose at eye level, relaxed shoulders, hands relaxed at sides with gently curled fingers He waits for the child to place a foot before helping him up. Relaxed brows, eyes fixed on the boy’s footing, lips softly closed; patient, practical help.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_chafu_p01_c01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-031、D-COS-038、R-SPR-022

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
