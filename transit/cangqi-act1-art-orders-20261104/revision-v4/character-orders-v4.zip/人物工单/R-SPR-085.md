# R-SPR-085　磨镰老汉 · 平常

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

他自己常做使力的活，扫一眼孩子的胳膊就有了判断。眉横着略压，眼皮眯起一点，视线落在那根细胳膊上，嘴唇尚且合着，结论已经有了。

- **眉**　灰眉平压
- **眼与视线**　眼皮微眯，看向胳膊
- **嘴**　薄唇自然闭合
- **演出用途**　掂量来换饭的孩子能不能劈柴
- **表演依据**　20:L10、20:L18
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_molao_p01_c01_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

20（套装定版／标准基准）

### 原文锚点

20:L10、20:L18；20:L10

### 镜头、时段及状态

村汉磨镰短衣；正面自然站立；站立全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_molao（老人）（D-CH-029）、ch_molao/c01（D-COS-036）

### 画面内必须可见

补：窄脸高颧、唇薄、短灰须；补：灰发束在脑后；窄袖短褂长裤，裤脚扎紧；深色头布

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。本张与身份、衣装合并提交角色定版。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. elderly farmer with high cheekbones, thin lips and short gray beard, wiry build and veined hands coarse brown work jacket, tied trouser cuffs, dark head wrap front-facing natural standing pose at eye level, relaxed shoulders, hands relaxed at sides with gently curled fingers A practiced laborer judges the boy’s strength by his thin arm. Low flat brows, a mild squint directed at the arm, thin closed lips while the verdict forms.. Full length from head to soles, feet at (512,2030), complete hands, feet and costume inside clear margins. Subject height 1980 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_molao_p01_c01_full；脚底锚点 (512,2030)，主体高 1980 px，四边留空；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-029、D-COS-036

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
