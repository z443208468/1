# R-SPR-059　蓝头巾妇人 · 平常

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

她篮子重，走得不快，却肯为一个陌生孩子停下来。取她愿意听的一眼。眉尾略垂，目光落到孩子脸上就安稳待着，嘴唇轻合，给他把话说完的工夫。

- **眉**　眉尾略垂
- **眼与视线**　耐心看着孩子
- **嘴**　嘴唇轻合
- **演出用途**　听见孩子叫她，停下脚步
- **表演依据**　14:L50、14:L53
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_lanjin_p01_c01_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

14（套装定版／标准基准）

### 原文锚点

14:L50、14:L53；14:L49、14:L50、14:L53、14:L58；14:L49、14:L50

### 镜头、时段及状态

褪蓝衫与蓝头巾；正面自然站立；站立全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_lanjin（成年）（D-CH-027）、ch_lanjin/c01（D-COS-034）

### 画面内必须可见

补：长面颊、下弯眉尾；头包蓝布；补：发丝在后颈收净；旧布衫外罩半身围腰，头巾包发；篮子按巷口场面承载

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。本张与身份、衣装合并提交角色定版。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. adult woman in a faded blue kerchief, elongated cheeks, lowered brow tails, work-worn hands washed-out blue cloth shirt and blue head scarf front-facing natural standing pose at eye level, relaxed shoulders, hands relaxed at sides with gently curled fingers Despite her heavy basket, she stops and gives the child time. Brow tails rest low, gaze patiently meets the boy, lips close softly to listen.. Full length from head to soles, feet at (512,2030), complete hands, feet and costume inside clear margins. Subject height 1980 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_lanjin_p01_c01_full；脚底锚点 (512,2030)，主体高 1980 px，四边留空；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-027、D-COS-034

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
