# R-SPR-143　靖王世子 · 从容

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

世子一向有人护着，还没开口就觉得事会照他的意思办。修齐的眉舒着，眼皮略沉，嘴角像生来便带一点钩。让这点有恃无恐在安静时也看得出。

- **眉**　修齐的眉舒展
- **眼与视线**　眼皮略沉
- **嘴**　一边唇角自然微勾
- **演出用途**　初从车帘后探脸，等旁人让路
- **表演依据**　26:L5
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_shizi_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；两手略离衣侧以露腕镯，不抓车帘；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

衣装适用 26–28；状态调用见场景需求

### 原文锚点

26:L5；26:L5、27:L17、27:L31、28:L26；26:L5、27:L14、27:L17、27:L18

### 镜头、时段及状态

世子锦袍；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_shizi（青年·二十来岁） D-CH-015、ch_shizi/c01

### 画面内必须可见

白里透红，修齐眉毛，嘴角素来上勾；束发戴冠；补：黑发、发冠居正；锦袍覆盖月白中衣，发冠正束，袖口露手镯；腕钏、发冠；衣身破损交给x01

### 位置、比例、遮挡和物件关系

正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

两手略离衣侧以露腕镯，不抓车帘

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Young nobleman in his twenties, 174 cm, fair skin with a rosy cast, groomed brows and naturally upturned lip corners. Medium build, pale wrists, black hair tied into a centered formal crown in the intact state. Glossy burgundy-purple brocade robe with narrow subdued patterns over a moon-white inner robe, wrist bangle visible at the cuff and a formal hair crown. Tears and disarray apply only to the designated special-state variant. Front-facing with weight on both feet and toes slightly apart, head level, shoulders easy, both hands held slightly away from the robe to show the wrist bangle. Hands do not take hold of a curtain. Protected from consequences, the young lord expects others to move. Groomed brows rest smooth, lids hang a little heavy, one mouth corner sits in its habitual hook. Close portrait, crown to mid-thigh, subject height 1840 px, bottom anchor (512,2044). Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_shizi_p01_c01_close；主体高 1840 px，主体底边 (512,2044)，头顶至大腿中段，底边截身。

### 依赖工单ref（depends_on）

D-CH-015、D-COS-022、R-SPR-144

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
