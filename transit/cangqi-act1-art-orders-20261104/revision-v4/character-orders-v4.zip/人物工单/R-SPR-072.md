# R-SPR-072　太学老门房 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

新人进门，这位老门房照例要认一认人，手头的小事倒不值得停很久。灰眉平放，眼皮只抬一点就把人看清，嘴唇轻合在宽鼻下，像问完一句便等他自报来历。

- **眉**　灰眉平放
- **眼与视线**　小眼微抬，目光留神
- **嘴**　两唇轻合
- **演出用途**　门房里认一认新来的孩子
- **表演依据**　32:L52、33:L3
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_menlao_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；两手放松，钥匙串（obj_yaoshi）系在腰侧，不提钥匙；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

32

### 原文锚点

32:L52、33:L3；32:L52、33:L3、33:L5、33:L13；33:L6

### 镜头、时段及状态

老门房当值衣；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_menlao（老人）（D-CH-037）、ch_menlao/c01（D-COS-044）、obj_yaoshi（随承载画面绘制）

### 画面内必须可见

补：小眼、宽鼻、颊边纹；补：灰白发束以灰巾；耐磨短褂，腰边留系钥匙的位置；钥匙串当值时系腰间（obj_yaoshi）

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

两手放松，钥匙串（obj_yaoshi）系在腰侧，不提钥匙

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-074 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. older gatekeeper, small observant eyes, broad nose, creased cheeks, gray hair tied with gray cloth, slightly bowed back weathered gray-brown gatekeeper tunic and key ring at belt front-facing natural standing pose at eye level, relaxed shoulders, hands loose, ring of keys worn at belt The old gatekeeper sizes up the new arrival without fuss. Gray brows lie flat, eyes lift just enough to register him, lips rest after a short routine question.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_menlao_p01_c01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-037、D-COS-044、R-SPR-074

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
