# R-SPR-079　明穗 · 安静

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

柳浅还没有把信里的事说完，明穗本想接话，又把这点空处让给她。短眉舒着，上眼睑自然放松，目光留在柳浅身上，小嘴轻合，静里看得出她在听。

- **眉**　短柔眉自然
- **眼与视线**　眼睑舒缓
- **嘴**　小口轻闭
- **演出用途**　她留意到难堪就让别人先说
- **表演依据**　43:L13、43:L18
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_mingsui_p02_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

抱书静坐；同窗交谈、听课，等待发言；仅近景；坐稳微侧朝画面左；头轻垂再平视；双肩收拢，肩不抬；双手轻托夹干金莲的书（obj_huashu），书合拢在胸下；不露花瓣；不为递物、收剑或抓捕做连续动作帧；头顶至大腿中段；近景主体高1840，主体底边(512,2044)

### 涉及场次

43

### 原文锚点

43:L13、43:L18；43:L12、43:L27、43:L72；40:L41、40:L42、42:L34、43:L12、43:L16

### 镜头、时段及状态

青裙鹿皮靴；抱书静坐；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_mingsui（少年·太学同窗）（D-CH-019）、ch_mingsui/c01（D-COS-026）、obj_huashu（随承载画面绘制）

### 画面内必须可见

手指细，笑时眼睛先弯；补：圆润内眼角、短柔眉；补：黑发侧分后绾，素细绳固定；青裙配合脚鹿皮靴；内袖可收小帕；素绳束发，书与小帕按场入画

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。坐稳微侧朝画面左；头轻垂再平视；双肩收拢，肩不抬

### 本画面可见物件：持有人｜位置｜状态

双手轻托夹干金莲的书（obj_huashu），书合拢在胸下；不露花瓣

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-078 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. quiet adolescent girl, short soft brows, rounded inner eye corners, slim fingers, narrow shoulders, black hair gently side-parted and bound behind; her eyes smile before her mouth muted light blue-green skirt and soft top, light brown deerskin boots and simple hair tie seated quietly, both hands cradling a closed old book below chest, pressed flowers not visible She gives her friend time to finish speaking about the letter. Rest the short brows, relax the upper lids while keeping attentive eye contact, close the small lips gently.. Follow the exact body pose and crop specified above. Keep subject height 1840 px and bottom anchor (512,2044). Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_mingsui_p02_c01_close；主体底边 (512,2044)，主体高 1840 px。取景 头顶至大腿中段；近景主体高1840，主体底边(512,2044)；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-019、D-COS-026、R-SPR-078

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
