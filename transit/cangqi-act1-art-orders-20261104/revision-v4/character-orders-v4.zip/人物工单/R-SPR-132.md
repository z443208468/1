# R-SPR-132　石头 · 机警

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

石头在城西看过天离两回，连那只空碗都记得。街边混熟的孩子，平常脸上一直留着看人的精神。参差的眉略抬，目光有个准落点，宽嘴轻合，等找准时候才开腔。

- **眉**　浓淡参差的眉略抬
- **眼与视线**　视线落准对方
- **嘴**　宽嘴轻合
- **演出用途**　在街边认人，等着搭句话
- **表演依据**　13:L40、13:L47、14:L23
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_shitou_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；两手放松，手肘略离腰，随时能迈步；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

13

### 原文锚点

13:L40、13:L47、14:L23；13:L40、13:L55、14:L60；13:L40、14:L48

### 镜头、时段及状态

小孩行乞装；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_shitou（童年·初识） D-CH-006、ch_shitou/c01

### 画面内必须可见

脸上一道黑一道白；补：短鼻、嘴宽、眉灵活；门牙缺一颗（初见明写，两年后不判定缺口是否补齐）；乱蓬蓬；补：黑短发乱束；短褂缩腰，长裤可卷脚；布绳束腰、软布鞋

### 位置、比例、遮挡和物件关系

正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

两手放松，手肘略离腰，随时能迈步

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Street child at first meeting, 132 cm, face streaked with dark and light grime, short nose, wide mouth, one missing front tooth and quick expressive brows. Tousled black hair loosely tied, light frame and strong forearms. Waist-tied short jacket of worn gray tea-brown hemp, fraying cuffs, long trousers with rollable hems, cloth rope belt and soft cloth shoes. Standing front-on, feet sharing weight with toes slightly apart, head and gaze level, shoulders loose. Hands relaxed, elbows a little away from the waist, poised to step without moving; no handheld prop. A streetwise boy who notices people and remembers even an empty bowl. Uneven brows lift a fraction, eyes settle on a particular face, broad mouth rests shut, ready to speak. Close portrait, crown to mid-thigh, subject height 1840 px, bottom anchor (512,2044). Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_shitou_p01_c01_close；主体高 1840 px，主体底边 (512,2044)，头顶至大腿中段，底边截身。

### 依赖工单ref（depends_on）

D-CH-006、D-COS-011、R-SPR-135

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
