# R-SPR-051　齐宣王府灰袍侍从 · 平常

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

他在王府办差，来人得觉得好开口，又不能把他当成可以随意打听的熟人。眉放平，目光稳稳迎上去，眼角刚起细纹，唇角只提一线，笑到这里就够。

- **眉**　眉势舒平
- **眼与视线**　目光坦然相接，眼角浅纹
- **嘴**　唇角微提一线
- **演出用途**　在宫墙根等人，办交接的差事
- **表演依据**　31:L45、32:L3
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_huipao_p01_c01_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；自然站稳，两足间距不大；头正，平视；收肩，礼貌而不卑躬；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

31、32（套装定版／标准基准）

### 原文锚点

31:L45、32:L3；31:L45、32:L3、32:L13、32:L34；31:L45、32:L10

### 镜头、时段及状态

王府灰袍；正面自然站立；站立全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_huipao（中年·四十来岁）（D-CH-035）、ch_huipao/c01（D-COS-042）

### 画面内必须可见

礼貌定量的笑；补：长脸、细眼纹；补：鬓边微灰，发髻低于王爷；端整长袍，比王爷外袍收身；素腰带，低束髻

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；自然站稳，两足间距不大；头正，平视；收肩，礼貌而不卑躬

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。本张与身份、衣装合并提交角色定版。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. forty-something household attendant, elongated face and fine eye creases, measured courteous smile, low tied hair with gray temples neat fitted gray robe, plain sash, no lord's high coronet front-facing natural standing pose at eye level, relaxed shoulders, hands relaxed at sides with gently curled fingers The practiced attendant gives an approachable but measured welcome. Brows lie smooth, gaze meets the guest, fine creases touch the eyes, lips lift by a hair.. Full length from head to soles, feet at (512,2030), complete hands, feet and costume inside clear margins. Subject height 1980 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_huipao_p01_c01_full；脚底锚点 (512,2030)，主体高 1980 px，四边留空；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-035、D-COS-042

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
