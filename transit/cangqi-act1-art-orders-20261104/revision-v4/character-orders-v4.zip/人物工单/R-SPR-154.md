# R-SPR-154　思柔 · 警醒

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

她松开了天离，却只退一步，仍想顾着身后的同伴。直眉平放，亮眼睁足，目光落在面前的人身上，嘴利落合着。这是她安静时也肯盯住事的样子。

- **眉**　直眉舒平
- **眼与视线**　亮眼睁足
- **嘴**　嘴合得利索
- **演出用途**　即使不说话也留心身边同伴
- **表演依据**　40:L45、43:L6
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_sirou_p01_c01_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双臂自然松抱于胸腹之间，手指落在对侧肘旁；站稳、肩放松，手中无物。；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

衣装适用 39–43；状态调用见场景需求

### 原文锚点

40:L45、43:L6；40:L45、41:L5；40:L9、42:L29、43:L6

### 镜头、时段及状态

深色窄袖学衣；正面自然站立；全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_sirou（少年·太学同窗） D-CH-017、ch_sirou/c01

### 画面内必须可见

双眼亮；补：清晰直眉、眉峰收锐、下颌轻收；头发利落束在脑后；补：黑发束紧；深色窄袖，腰束紧，下摆利于迈步；软底鞋；高束发绳，无垂坠挂饰

### 位置、比例、遮挡和物件关系

正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双臂自然松抱于胸腹之间，手指落在对侧肘旁；站稳、肩放松，手中无物。

### 不得出现的对象（forbiddenEarly）

额外人物、文字、地面和背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01，核对本年龄身份、衣装、同组已有基准与项目登记

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. Adolescent female academy student, 155 cm, bright eyes, clear straight brows with defined peaks, tapering chin and cheeks reddened by winter wind. Black hair tied back firmly, small strong hands and steady legs. Dark ink-blue tightly woven student clothing, narrow sleeves, tightly belted waist with a dark teal sash, hem cut for a long stride, soft-soled shoes and a high hair tie without hanging ornaments. Front-facing stable stance with weight on both feet, toes slightly apart, head and eyes level and shoulders loose. Arms loosely folded between chest and abdomen, fingers resting beside the opposite elbows, hands empty. She eases her grip but stays alert for her friends. Straight resting brows, clear eyes wide enough to track the person ahead, both lips neatly closed. Full figure, 1980 px high, soles at (512,2030), include head, hands and feet. Only include items specified in the pose. Single figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_sirou_p01_c01_full；全身主体高 1980 px，足底中点 (512,2030)，完整保留头手足。

### 依赖工单ref（depends_on）

D-CH-017、D-COS-024

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
