# R-SPR-116　齐宣王 · 闲定

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

孩子一时答不上来，他也肯等。先生的闲适里有一股注意力，不用端起威严来催人。画安静等候的那一刻，眉梢自然铺开，圆眼半松却望得专心，胡茬间的两唇安稳合住。

- **眉**　眉梢松开
- **眼与视线**　圆眼温和、注意力未散
- **嘴**　胡茬围住的嘴自然合上
- **演出用途**　孩子迟疑时给他把话想明白的时间。
- **表演依据**　35:L35
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_qixuanwang_p03_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

稳坐听答；在府中与讲堂坐问、听答；仅近景；坐稳，朝画面右偏约15度，髋部后沉；平视或微俯；肩松，背部自然直起；双手松落膝前，无杯无扇。茶杯搁下由相应空景承载。；不把端杯、喝茶和拍腿画作连续动作帧；头顶至大腿中段；近景主体高1840，主体底边(512,2044)

### 涉及场次

32

### 原文锚点

35:L35；32:L10、32:L24、43:L32、43:L87；32:L10、34:L19、36:L4、38:L42

### 镜头、时段及状态

灰袍高冠；稳坐听答；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_qixuanwang（成年·三十来岁）（D-CH-016）、ch_qixuanwang/c01（D-COS-023）

### 画面内必须可见

圆脸，修整齐的胡茬，眼睛可瞪圆；补：眉丰直；发冠高束；补：黑发收净；灰色宽袍束腰，足以把折扇插腰；高发冠；折扇、茶杯按姿势或场景分别表现

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。坐稳，朝画面右偏约15度，髋部后沉；平视或微俯；肩松，背部自然直起

### 本画面可见物件：持有人｜位置｜状态

双手松落膝前，无杯无扇。茶杯搁下由相应空景承载。

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-110 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. man in his thirties, round face, neatly trimmed stubble, full level brows and lively round eyes, hair in high coronet, broad frame and easy authority plain loose gray robe with modest dark gray lining and sash, high hair coronet, no court regalia seated, slightly turned three quarters, shoulders easy, hands relaxed in lap, no fan, tea cup or furniture in sprite An unhurried teacher waiting for the child to find an answer. Loose brow tails, relaxed round eyes holding a point of focus, closed mouth at rest within the stubble.. Follow the exact body pose and crop specified above. Keep subject height 1840 px and bottom anchor (512,2044). Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_qixuanwang_p03_c01_close；主体底边 (512,2044)，主体高 1840 px。取景 头顶至大腿中段；近景主体高1840，主体底边(512,2044)；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-016、D-COS-023、R-SPR-110

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
