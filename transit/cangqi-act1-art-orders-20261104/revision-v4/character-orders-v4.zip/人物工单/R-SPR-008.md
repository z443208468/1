# R-SPR-008　疤脸 · 沉着

**全身基准　｜　前置采纳后排产**

## 这张脸为什么这样画

疤脸认生人，罐边的孩子还等他分吃的。他得先听明白来人是谁，眉就平平压着，上眼皮半盖，目光落得稳。唇合拢等对方说话，左颊的疤跟着脸安静下来。

- **眉**　两眉低平
- **眼与视线**　上眼皮略盖眼瞳，凝视来人
- **嘴**　嘴唇轻合，左颊疤不牵动
- **演出用途**　分汤时停下来认新面孔
- **表演依据**　14:L4、14:L9
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_balian_p01_c03_full_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；一手松垂，另一手停腰侧，不持棍；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

16回访（套装定版／标准基准）

### 原文锚点

14:L4、14:L9；14:L4、14:L17、14:L24、14:L45；16:L25、16:L27

### 镜头、时段及状态

药铺洗碾短褂；正面自然站立；站立全身；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_balian（童年后期·两年后）（D-CH-009）、ch_balian/c03（D-COS-015）

### 画面内必须可见

同一左颊旧疤；补：颊部更清瘦；补：沿用后颈小结；药铺伙计洗白的短褂，配旧长裤；朴素布带

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

一手松垂，另一手停腰侧，不持棍

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-005 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. older thin boy, same pale left-cheek scar, square chin, dark nape knot, narrower cheeks, taller proportions; do not change scar direction washed-out pale gray pharmacy worker's short jacket, old trousers and unadorned cloth sash front-facing natural standing pose at eye level, relaxed shoulders, one hand lowered, one at the waist, no stick The boy tending the food pauses to size up a newcomer. Low level brows, hooded steady eyes, mouth quietly shut, left cheek scar at rest.. Full length from head to soles, feet at (512,2030), complete hands, feet and costume inside clear margins. Subject height 1980 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=full；兼容组 ch_balian_p01_c03_full；脚底锚点 (512,2030)，主体高 1980 px，四边留空；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-009、D-COS-015、R-SPR-005

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
