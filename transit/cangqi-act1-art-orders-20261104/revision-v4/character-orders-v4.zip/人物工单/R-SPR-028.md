# R-SPR-028　二柱 · 平常

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

黄头发一说有热闹，二柱醒得倒快。取他刚把注意力转到同伴脸上的时候。眉尾挑起一点，圆眼有了亮光，嘴角还没咧开，先等着听到底有什么好看。

- **眉**　眉尾微挑
- **眼与视线**　圆眼睁醒，望向同伴
- **嘴**　嘴自然闭，嘴角平
- **演出用途**　刚醒，听见有人约他看热闹
- **表演依据**　17:L7、17:L8
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_erzhu_p01_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

正面自然站立；会面、对话与身份识别；全身+近景；正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态；双手松垂身侧，掌指自然弯曲，空手；不做追逐、递交、骤然施力等瞬时动作；全身主体高1980；近景头顶至大腿中段，主体高1840

### 涉及场次

15

### 原文锚点

17:L7、17:L8；15:L7、16:L29、17:L4；16:L29

### 镜头、时段及状态

缺牙庙童旧衣；正面自然站立；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_erzhu（童年）（D-CH-024）、ch_erzhu/c01（D-COS-031）

### 画面内必须可见

门牙有缺；补：圆鼻、脸短；补：黑发向额前乱翘；短袖衫露细手腕，宽松旧裤；破布系带

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。正面；重心分落双脚、足尖微分；头正，平视；自然松肩，脊背保持本人的体态

### 本画面可见物件：持有人｜位置｜状态

双手松垂身侧，掌指自然弯曲，空手

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-030 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. child with a gap in his front teeth, round nose, short face, tousled black fringe and thin arms faded brown child's shirt and loose old trousers front-facing natural standing pose at eye level, relaxed shoulders, hands relaxed at sides with gently curled fingers Awakened by the promise of something to see, he listens for the details. Brow tails lift a fraction, round eyes brighten, mouth stays closed before any grin.. Close portrait from crown to mid-thigh, lower body cropped at the bottom, bottom anchor (512,2044), subject height 1840 px. Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_erzhu_p01_c01_close；主体底边 (512,2044)，主体高 1840 px，顶至大腿中段，底边截身；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-024、D-COS-031、R-SPR-030

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
