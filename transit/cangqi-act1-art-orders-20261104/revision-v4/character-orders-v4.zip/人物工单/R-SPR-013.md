# R-SPR-013　疤脸 · 沉着

**特殊状态基准　｜　前置采纳后排产**

## 这张脸为什么这样画

他平常把自己的难受往后搁，吃食还是照常分。病没好，安静下来时才显出疲色。眉压平，眼皮比平时重一点，嘴唇轻启换气，留定左颊的旧疤。

- **眉**　低眉持平
- **眼与视线**　眼皮略沉，目光仍定
- **嘴**　唇略开换气
- **演出用途**　咳病期间的可复用静帧
- **表演依据**　15:L7、16:L4、16:L53
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_balian_p02_c02_x01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

庙中坐守；守火分食、靠墙歇病；仅近景；坐低，上身向画面左转一点，膝头靠近；头稍低，眼能看清；肩内收，背略弯；前臂靠近膝头，两手空着；不固定盛汤、拨灰的瞬态；不为递物、收剑或抓捕做连续动作帧；头顶至大腿中段；近景主体高1840，主体底边(512,2044)

### 涉及场次

15

### 原文锚点

15:L7、16:L4、16:L53；14:L4、14:L22、15:L7；15:L7、16:L4

### 镜头、时段及状态

庙中长个旧衣；庙中坐守；近景；咳病未愈 面部带病后倦色，鼻口略堵，肩部可能内收；左颊疤位置不动

### 引用的实体与设计（档案ID＋设计工单ref）

ch_balian（童年后期·两年后）（D-CH-009）、ch_balian/c02（D-COS-014）、ch_balian/x01（D-X-004）

### 画面内必须可见

同一左颊旧疤；补：颊部更清瘦；补：沿用后颈小结；短褂渐短，裤腿贴瘦长双腿，外面可坐卧在草席边；旧布腰带，无首饰；面部带病后倦色，鼻口略堵，肩部可能内收；左颊疤位置不动

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。坐低，上身向画面左转一点，膝头靠近；头稍低，眼能看清；肩内收，背略弯

### 本画面可见物件：持有人｜位置｜状态

前臂靠近膝头，两手空着；不固定盛汤、拨灰的瞬态

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-005 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. older thin boy, same pale left-cheek scar, square chin, dark nape knot, narrower cheeks, taller proportions; do not change scar direction outgrown dark-brown coarse tunic, cloth belt and narrow trousers, no jewelry low seated older street boy with bent knees, forward shoulders, forearms resting close to knees, empty hands lingering cough, tired eyelids, slight nasal redness, same left cheek scar; no blood or severe fever He keeps his usual composure while recovering from a cough. Level low brows, slightly heavier lids, lips parted just enough for breath, left-cheek scar fixed.. Follow the exact body pose and crop specified above. Keep subject height 1840 px and bottom anchor (512,2044). Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_balian_p02_c02_x01_close；主体底边 (512,2044)，主体高 1840 px。取景 头顶至大腿中段；近景主体高1840，主体底边(512,2044)；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-009、D-COS-014、D-X-004、R-SPR-005

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
