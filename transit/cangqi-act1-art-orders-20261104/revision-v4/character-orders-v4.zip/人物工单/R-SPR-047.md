# R-SPR-047　黄头发 · 伶醒

**近景基准　｜　前置采纳后排产**

## 这张脸为什么这样画

他杵一下天离的腰，想知道同伴有没有瞧见自己发现的事。嘴难得合上一刻，两眉松着，只有上眼皮轻挑，大眼睛盯住对方，已经在等一句回话。

- **眉**　眉毛松松地搭着
- **眼与视线**　上眼睑轻挑，目光等对方回应
- **嘴**　瘦脸上闭口
- **演出用途**　发现动静，示意天离也留意
- **表演依据**　18:L6
- **调用**　演出设计

## 生产信息

### 资源状态ID（合法状态ID、背景状态ID或特写ID）

ch_huangfa_p02_c01_close_e01

### 【姿势要求】（基准必填，照抄姿势定义）

靠墙歇脚；街上望风、离别前的闲谈；仅近景；上身向画面右轻倾，背部有支点；下颌微扬；一侧肩略低；双臂松抱胸前，指尖露在对侧袖外；不为递物、收剑或抓捕做连续动作帧；头顶至大腿中段；近景主体高1840，主体底边(512,2044)

### 涉及场次

18

### 原文锚点

18:L6；18:L19、18:L52；15:L7、16:L32、18:L19

### 镜头、时段及状态

破庙小儿便装；靠墙歇脚；近景；常态

### 引用的实体与设计（档案ID＋设计工单ref）

ch_huangfa（童年·天离离玄阳前）（D-CH-012）、ch_huangfa/c01（D-COS-018）

### 画面内必须可见

瘦得脱相；补：颊凹、眼大、门齿齐；头发黄得像枯稻草；补：草黄乱短发；松垮短褂、过膝旧裤、软鞋；素麻带，无贵重物

### 位置、比例、遮挡和物件关系

肩线、手位及重心按本组姿势锁定。上身向画面右轻倾，背部有支点；下颌微扬；一侧肩略低

### 本画面可见物件：持有人｜位置｜状态

双臂松抱胸前，指尖露在对侧袖外

### 不得出现的对象（forbiddenEarly）

额外肢体、衣饰、文字、地面与背景

### 可用的项目内参考

项目风格锚 CQ_STYLE_REF_01；对应身份与衣装设计。首张站立样板 R-SPR-046 经用户定版后放行。

### 生成提示词（英文；基准、背景、特写开头粘贴完整风格锚原文，不用占位符；表情差分只写表情部分）

Fine digital painting with selective colored linework and continuous soft form modeling. Vary crisp structural edges with softened light-facing, translucent, and distant edges. Render faces with refined idealized painterly volume while preserving each work order's identity, age, and proportions. Build hair from grouped masses with selective strands and highlights; distinguish materials through their own light response. Use cool-warm color interplay, colored shadows, controlled highlights, and atmospheric depth, while the work order determines the actual palette, lighting, subject, pose, composition, and content. small wiry street child, dry straw-yellow tousled hair, hollow cheeks and large quick eyes, no missing front tooth loose dirty cool-gray tunic, patched knee-length trousers, plain cord belt and worn soft shoes leaning slightly toward an implied wall, arms loosely crossed, chin slightly raised, no painted wall He has just nudged his friend to share a discovery. Loose brows, lively open eyes waiting for a response, both lips briefly together.. Follow the exact body pose and crop specified above. Keep subject height 1840 px and bottom anchor (512,2044). Only include handheld items specified in this pose. Single isolated figure, transparent background.

### 输出规格（画布、格式、透明、frame、兼容组、锚点、主体高）

1024×2048 透明 PNG；frame=close；兼容组 ch_huangfa_p02_c01_close；主体底边 (512,2044)，主体高 1840 px。取景 头顶至大腿中段；近景主体高1840，主体底边(512,2044)；whole-image，一状态一张整图。

### 依赖工单ref（depends_on）

D-CH-012、D-COS-018、R-SPR-046

### 优先级

前置采纳后排产｜必须

### 开工条件

项目库查重并完成所列前置审批。
